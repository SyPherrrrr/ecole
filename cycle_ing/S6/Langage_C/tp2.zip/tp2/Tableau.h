

void InitTabRandom(int *tab, unsigned int size, int min, int max);
//unsigned pour enlever les valeurs négztives -> économie de stockage


void printTab(int *tab, unsigned int size);

int CheckSortTabCroissant(int *tab, unsigned int size);

int CheckSortTabDecroissant(int *tab, unsigned int size);

void printCheckSortTab(int *tab, unsigned int size);

void printTabTimer(double *tab_time, unsigned int size);

