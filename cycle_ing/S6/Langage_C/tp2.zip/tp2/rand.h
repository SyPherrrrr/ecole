

void RandInit();
int RandInt(int min, int max);
double RandDouble(double min, double max);