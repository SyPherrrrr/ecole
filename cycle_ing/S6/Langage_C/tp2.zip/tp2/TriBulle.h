
void TriBulle(int *tab, int premier, int dernier, int (*compare)(int, int));
