Petit readme pour savoir comment executer et compiler mon code.

J'ai 2 mains dans mon fichier main.c : Il faut enlever /* et */ au début et à la fin
du main pour exécuter celui qu'on veut.

voici la commande pour compiler et executer :
 gcc -Wall -o fichier_executable main.c Tableau.c rand.c MyQuickSort.c fonctions_sort.c TriBulle.c util.c horloge.c

./fichier_executable

@Elias