
int croissant(int a , int b);

int decroissant(int a , int b);

int comparePairsFirst(int a, int b);

int compareImpairsFirst(int a, int b);


