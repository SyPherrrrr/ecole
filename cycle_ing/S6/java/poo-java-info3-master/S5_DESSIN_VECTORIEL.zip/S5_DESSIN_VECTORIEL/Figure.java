import java.awt.*;


public interface Figure {

    public default void draw(Graphics2D g) {

    }
}
